# quarkus_projects


https://quarkus.io/

https://code.quarkus.io/

Eclipse ->  Help -> marketplace -> quarkus

application.properties (na pasta resources) : quarkus.http.port=8080

Run -> Configuration -> Quarkus -> Run



References:

https://www.logicmonitor.com/blog/quarkus-vs-spring
