package org.park;

public class Livro {

	private String id;
	private Especificacao espc;
	
	
	public Livro(String id, Especificacao espc){
		this.id = id;
		this.espc = espc;
		
	}
	
	public String getId(){
		return this.id;
	}
	
	public Especificacao getEspc(){
		return espc;
	}
	
	
}
