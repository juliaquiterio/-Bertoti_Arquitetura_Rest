package org.park;


import java.util.List;
import java.util.LinkedList;

public class Model {
	
	private List<Livro> livros = new LinkedList<Livro>();

	public Model() {
		addLivro(new Livro("HPS959", new Especificacao("Romance", "A Culpa é das Estrelas", "Digital")));
		addLivro(new Livro("KSO741", new Especificacao("Fantasia", "Harry Potter", "Físico")));
		addLivro(new Livro("UIMMS9", new Especificacao("Suspense", "Fuja", "Físico")));
	}
	
	public void addLivro(Livro livro){
		livros.add(livro);
	}
	
	public Livro buscarId(String id){
		for(Livro livro:livros){
			if(livro.getId().equals(id)) return livro;
		}
		
		return null;
	}
	
	
	public List<Livro> buscarEspecificacao(Especificacao esp){
		List<Livro> livrosEncontrados = new LinkedList<Livro>();
		
		for(Livro livro:livros){
			 if(esp.comparar(livro.getEspc())) livrosEncontrados.add(livro);
		}
		
		return livrosEncontrados;
		
	}
	
	
	public List<Livro> buscarModelo(String genero){
		List<Livro> livrosEncontrados = new LinkedList<Livro>();
		for(Livro livro:livros) {
			if(livro.getEspc().getGenero().equals(genero)) livrosEncontrados.add(livro);
		}
		return livrosEncontrados;
	}
	
	public List<Livro> getLivros(){
		return livros;
	}

}
