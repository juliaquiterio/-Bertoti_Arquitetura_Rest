package org.park;
public class Especificacao {

	
	private String genero;
	private String titulo;
	private String plataforma_f_d;
	
	
	public Especificacao(String genero, String titulo, String plataforma_f_d){
		this.genero = genero;
		this.titulo = titulo;
		this.plataforma_f_d = plataforma_f_d;
	}
	
	public String getGenero(){
		return genero;
	}
	
	public String getTitulo(){
		return titulo;
	}
	
	public String getPlataforma_f_d(){
		return plataforma_f_d;
	}
	
	//delegacao da comparacao de titulo, genero e plataforma_f_d do livro para a classe Especificacao, pois ela eh a dona dos atributos
	public boolean comparar(Especificacao esp){
		if(titulo.equals(esp.titulo) && genero.equals(esp.genero) && plataforma_f_d.equals(esp.plataforma_f_d)){
			return true;
		} else {
			return false;
		}
	}
	
}
