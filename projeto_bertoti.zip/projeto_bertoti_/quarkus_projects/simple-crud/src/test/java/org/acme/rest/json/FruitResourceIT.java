package org.acme.rest.json;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class FruitResourceIT extends FruitResourceTest {

}