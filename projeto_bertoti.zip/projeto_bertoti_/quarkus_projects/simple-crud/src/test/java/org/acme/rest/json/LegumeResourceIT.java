package org.acme.rest.json;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class LegumeResourceIT extends LegumeResourceTest {

}